-- phpMyAdmin SQL Dump
-- version 3.3.3
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 27, 2012 at 02:21 PM
-- Server version: 5.1.50
-- PHP Version: 5.3.14

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `test`
--

-- --------------------------------------------------------

--
-- Table structure for table `visit`
--

CREATE TABLE IF NOT EXISTS `visit` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `studentID` varchar(8) NOT NULL DEFAULT '99999999',
  `name` varchar(255) DEFAULT NULL COMMENT 'Student Name',
  `course` varchar(10) NOT NULL,
  `arrivalTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Time the Student Arrived',
  `needHelp` varchar(5) NOT NULL COMMENT 'Does the student need help today?',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=25 ;

--
-- Dumping data for table `visit`
--

INSERT INTO `visit` (`id`, `studentID`, `name`, `course`, `arrivalTime`, `needHelp`) VALUES
(9, '90000090', NULL, 'CS 350', '2012-11-21 12:10:04', 'No'),
(10, '03224744', NULL, 'CS 350', '2012-11-21 12:28:25', 'No'),
(13, '09800980', NULL, 'CS 350', '2012-11-21 12:38:55', 'No'),
(15, 'derpderp', NULL, 'CS 360', '2012-11-21 13:19:47', 'No'),
(23, '03185406', NULL, 'CS 280', '2012-11-27 14:05:09', 'Yes'),
(24, '03224844', NULL, 'CS 480', '2012-11-27 14:05:58', 'Yes');
